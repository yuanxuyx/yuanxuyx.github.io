1. Check your existing virtual environment

	conda env list

2. If not installed, installed the followings

	conda install -c anaconda keras
	conda install -c conda-forge matplotlib
	conda install -c anaconda scikit-learn
3. If your numpy version is 1.19+, downgrade to 1.18.5

	pip install -U numpy==1.18.5