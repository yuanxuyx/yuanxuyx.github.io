from __future__ import print_function
from keras.models import Model
from keras.layers import Input, LSTM, Dense,  Add
import numpy as np
from weather import Weather
from sklearn.preprocessing import MinMaxScaler
from keras.models import load_model
import pandas as pd
# from keras.utils.vis_utils import plot_model

m = Weather()

m.station = 'atmore'

m.test_feature_list =  ["PTemp"]
#m.test_feature_list = ["Temp_C"]
#m.test_feature_list = ["RH_2m"]
# m.test_feature_list = ["WndDir_2m"]
# m.test_feature_list = ["WndSpd_2m"]
# m.test_feature_list = ["Pressure_1"]
# m.test_feature_list = ["Precip_TB3_Tot"]

import argparse
import sys

args=sys.argv[1:]

#m.station = args[0]
#m.test_feature_list = [args[1]]



global_path = "cache/"+m.station+"_LSTM_"+m.test_feature_list[0]+"_no"

train = True
# m.station = 'atmore'
# m.station = 'foley'
during = 9
year_during = 1


train_x, train_y = m.read_lstm_file(year = "2018", year_during = year_during, start_date = "0301", during = 9, shift=5, seq = 5)   
x_scaler = MinMaxScaler()
x_scaler.fit(train_x)
train_x = x_scaler.transform(train_x)
x_train = train_x


y_scaler = MinMaxScaler()
y_scaler.fit(train_y)
train_y = y_scaler.transform(train_y)
y_train = train_y


y_train_L = y_train.reshape(1, y_train.shape[0])[0]
x_train = np.array(x_train)
y_train_L = np.array(y_train_L)

encoder_input_data, decoder_input_data, decoder_target_data = m.pre_seq(x_train, y_train_L)

during = 1
start_date = "0301"
test_x, test_y = m.read_lstm_file(year = "2019", year_during = 1, start_date = "0308", during = during, shift=5, seq = 5)    


test_x = x_scaler.transform(test_x)
x_test = test_x

test_y = y_scaler.transform(test_y)
y_test = test_y


y_test_L = y_test.reshape(1, y_test.shape[0])[0]
x_test = np.array(x_test)
y_test_L = np.array(y_test_L)
print("Printing labeled data")
print(y_test_L)
test_encoder_input_data, test_decoder_input_data, test_decoder_target_data = m.pre_seq(x_test, y_test_L)



batch_size = 64  # Batch size for training.
epochs = 5  # Number of epochs to train for.
latent_dim = 256  # Latent dimensionality of the encoding space.
# Path to the data txt file on disk.




# Vectorize the data.

input_texts = encoder_input_data
input_len = len(input_texts)
target_texts = []


num_encoder_tokens = len(m.feature_list_full_value)
num_decoder_tokens = len(m.test_feature_list)+2
max_encoder_seq_length = 12
max_decoder_seq_length = 6+1


# Define an input sequence and process it.
encoder_inputs = Input(shape=(None, num_encoder_tokens))
encoder = LSTM(latent_dim, return_state=True)
encoder_outputs, state_h, state_c = encoder(encoder_inputs)
# We discard `encoder_outputs` and only keep the states.
encoder_states = [state_h, state_c]

# Set up the decoder, using `encoder_states` as initial state.
decoder_inputs = Input(shape=(None, num_decoder_tokens))
# We set up our decoder to return full output sequences,
# and to return internal states as well. We don't use the
# return states in the training model, but we will use them in inference.
decoder_lstm = LSTM(latent_dim, return_sequences=True, return_state=True)
decoder_outputs, _, _ = decoder_lstm(decoder_inputs, initial_state=encoder_states)
decoder_dense = Dense(num_decoder_tokens, activation='sigmoid')
decoder_outputs = decoder_dense(decoder_outputs)


# Define the model that will turn
# `encoder_input_data` & `decoder_input_data` into `decoder_target_data`
model = Model([encoder_inputs, decoder_inputs], decoder_outputs)



# Run training
model.compile(optimizer='adam', loss='mean_squared_error', metrics=['accuracy'])


if train:
    model.fit([encoder_input_data, decoder_input_data], decoder_target_data,batch_size=batch_size, epochs=epochs, validation_split=0.2, verbose=0)
    # Save model
    model.save(global_path+'.model')

model = load_model(global_path+'.model')


# Next: inference mode (sampling).
# Here's the drill:
# 1) encode input and retrieve initial decoder state
# 2) run one step of decoder with this initial state
# and a "start of sequence" token as target.
# Output will be the next target token
# 3) Repeat with the current target token and current states
# Define sampling models
encoder_model = Model(encoder_inputs, encoder_states)
decoder_state_input_h = Input(shape=(latent_dim,))
decoder_state_input_c = Input(shape=(latent_dim,))
decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]
decoder_outputs, state_h, state_c = decoder_lstm(decoder_inputs, initial_state=decoder_states_inputs)
decoder_states = [state_h, state_c]
decoder_outputs = decoder_dense(decoder_outputs)
decoder_model = Model([decoder_inputs] + decoder_states_inputs, [decoder_outputs] + decoder_states)

if train:
    encoder_model.save(global_path+'.encoder')
    decoder_model.save(global_path+'.decoder')

encoder_model = load_model(global_path+'.encoder')
decoder_model = load_model(global_path+'.decoder')


def decode_sequence(input_seq):
    # Encode the input as state vectors.
    states_value = encoder_model.predict(input_seq)

    # Generate empty target sequence of length 1.
    target_seq = np.zeros((1, 1, num_decoder_tokens))

    # Populate the first character of target sequence with the start character.
    # target_seq[0, 0, ] = 1.

    # Sampling loop for a batch of sequences
    # (to simplify, here we assume a batch of size 1).
    stop_condition = False
    decoded_sentence = []
    while not stop_condition:
            output_tokens, h, c = decoder_model.predict([target_seq] + states_value)

  
            pre_tmp_value = output_tokens[0,0,0]

            decoded_sentence.append(pre_tmp_value)
            end_bit = output_tokens[0,0,-1]
    
            # Exit condition: either hit max length
            # or find stop character.

            if (end_bit > 1 or len(decoded_sentence) > max_decoder_seq_length-1):
                stop_condition = True

            # Update the target sequence (of length 1).
            target_seq = np.zeros((1, 1, num_decoder_tokens))
            target_seq[0, 0, 0] = pre_tmp_value
            # Update states

            states_value = [h, c]

    return decoded_sentence



label_list = []
pre_list = []

for seq_index in range(len(test_encoder_input_data)):
#for seq_index in range(len(test_encoder_input_data)):
    # Take one sequence (part of the training set)
    # for trying out decoding.
    input_seq = test_encoder_input_data[seq_index: seq_index + 1]
 
    decoded_sentence = decode_sequence(input_seq)
    label_data = [i[0] for i in  test_decoder_target_data[seq_index]]
    
    if seq_index < 10:
        print('Label sentence:', label_data)
        # print('Label sentence:', decoder_target_data[seq_index])
        print('Decoded sentence:', decoded_sentence)

    label_list.append(label_data)
    pre_list.append(decoded_sentence)

print("########################")
# ans = m.draw_sequence(label_list, pre_list)
# print(ans)
# m.draw_lstm_without_e(label_list, pre_list, y_scaler, lstm_path = global_path)

# m.compute_mse_scalar(label_list, pre_list, y_scaler)
# m.compute_mse_winddir(label_list, pre_list, y_scaler)

m.draw_lstm_without_e(label_list, pre_list, y_scaler, lstm_path = global_path)





