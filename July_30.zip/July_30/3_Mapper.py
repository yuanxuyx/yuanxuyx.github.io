from weather import Weather
import matplotlib.pyplot as plt
from keras.models import Model
from keras.layers import Input, LSTM, Dense,  Add
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import matplotlib
from scipy.stats import norm
from sklearn.neighbors import KernelDensity
from sklearn.utils.fixes import parse_version
from scipy.signal import find_peaks
from keras.utils import to_categorical

plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams.update({'font.size': 24})
# plt.rcParams['figure.figsize'] = 16, 12

if parse_version(matplotlib.__version__) >= parse_version('2.1'):
    density_param = {'density': True}
else:
    density_param = {'normed': True}




m = Weather()
# m.station = 'elberta'
m.station = 'atmore'
# m.test_feature_list = ["RH_2m"]
m.test_feature_list = ["PTemp"]
#m.test_feature_list = ["WndDir_2m"]

Feature = "PTemp"

during = 9
year_during = 1
start_date = "0301"


peroid_x, peroid_y = m.read_lstm_file(year = "2018", year_during = year_during, start_date = start_date, during = during, shift=5, seq = 5)

print("reading data")


temp = peroid_x[[Feature]]

print(temp)

global_path = "cache/"+m.station+"_"+Feature

X_scaler = MinMaxScaler()
X_scaler.fit(temp)
X_train = X_scaler.transform(temp)

X = temp.values

encoder_input_data,  _ , _ = m.pre_seq(X_train, X_train)


encoder_input_data = encoder_input_data.reshape(-1, encoder_input_data.shape[1])



N = len(X)


plt.figure(figsize=(20, 6))
plt.plot(X)
plt.show()


X_plot = np.linspace(int(X.min()), int(X.max()), 1000)[:, np.newaxis]
bins = np.linspace(int(X.min()), int(X.max()), 10)


plt.hist(X, bins=bins, fc='#AAAAFF', **density_param)
plt.show()




# Gaussian KDE
kde = KernelDensity(kernel='gaussian', bandwidth=0.85).fit(X)
log_dens = kde.score_samples(X_plot)
plt.figure(figsize=(10, 8))
plt.fill(X_plot[:, 0], np.exp(log_dens), fc='#AAAAFF')
plt.ylabel('density')
plt.show()

maxima_index = log_dens.argmax()


X = np.reshape(X, (1, -1))[0]

mean_value = X_plot[maxima_index]
value_range = X.max()-X.min()
ratio_range = value_range*0.15/2
mean_range_max = mean_value+ratio_range
mean_range_min = mean_value-ratio_range

binary_X = []
for i in X:
    if i>mean_range_min and i<mean_range_max:
        binary_X.append(1)
    else:
        binary_X.append(-1)
plt.plot(binary_X)
plt.show()

from scipy.fft import fft, ifft

def periodic_corr(x, y):
    """Periodic correlation, implemented using the FFT.

    x and y must be real sequences with the same length.
    """
    return ifft(fft(x) * fft(y).conj()).real

y = fft(binary_X)
y_perio = []

c_idx = 0
for i in y:
    y_perio.append((i.real)**2+(i.imag)**2)

def peak_filter(input):
    output = [input[0]]
    cur = input[0]
    for x in input[1:]:
        if x-cur<100:
            continue
        else:
            cur = x
            output.append(x)
    return output

plt.plot(y_perio)
plt.show()

cross_correlation=periodic_corr(binary_X, binary_X)
peaks, _ = find_peaks(cross_correlation, prominence =1, width=50)
peaks = peak_filter(peaks)

plt.figure(figsize=(20, 6))
plt.plot(cross_correlation)
plt.plot(peaks, cross_correlation[peaks], 'xr')
plt.savefig("Fig/period.pdf", bbox_inches='tight')
plt.show()


plt.figure(figsize=(20, 6))
plt.plot(X)
plt.plot(peaks, X[peaks], 'xr')
plt.savefig("Fig/period2.pdf", bbox_inches='tight')
plt.show()

peak_list = [0]+peaks+[N]

def find_block(idx):
    block_id = -1
    for i in peak_list:
        if idx >= i:
            block_id += 1
        else:
            break
    return (peak_list[block_id], peak_list[block_id+1])


idx_count = 48   #24*60/30   48
idx_label = {}

for i in range(N):
    min_value, max_value = find_block(i)
    p_idx = int((i-min_value)/((max_value-min_value)/idx_count))/idx_count
    idx_label[i] = p_idx


X_train = X_train.reshape(1, X_train.shape[0])[0]
X_train = np.array(X_train)

# prepare index
Index = []
for x in range(len(X_train)):
    label = idx_label[x]
    Index.append(label)

Index = Index[:len(encoder_input_data)]

Index_Y = np.array(Index)

# Index_Y = to_categorical(Index)



num_encoder_tokens = len(encoder_input_data[0])
encoding_dim = 16

# This is our input image
encoder_inputs = Input(shape=(num_encoder_tokens))
# "encoded" is the encoded representation of the input
encoded = Dense(encoding_dim, activation='relu')(encoder_inputs)
# "decoded" is the lossy reconstruction of the input
decoded = Dense(1, activation='sigmoid')(encoded)

# This model maps an input to its reconstruction
autoencoder = Model(encoder_inputs, decoded)


# This model maps an input to its encoded representation
encoder = Model(encoder_inputs, encoded)

autoencoder.compile(optimizer='adam', loss='mean_squared_error')


autoencoder.fit(encoder_input_data, Index_Y,
                epochs=200,
                batch_size=64,
                shuffle=True)


encoder.save(global_path+'.mapper')

# ans = encoder.predict(encoder_input_data)
# print(ans)

