1. Create a new virtual environment

	conda create -n new_env python=3.8

2. Activate new environment
	
	conda activate new_env

3. Install the followings

	pip install tensorflow==2.3.1
	pip install keras==2.4.3

	conda install -c conda-forge matplotlib
	conda install -c anaconda scikit-learn
	conda install -c anaconda pandas

4. Downgrade the numpy

	pip install -U numpy==1.18.5